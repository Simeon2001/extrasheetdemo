new Vue ({
    el:'#app',
    data: {
        first:1
        
        
    },
    methods: {
        next : function(){
            this.first++;
        },    
        
    }
})