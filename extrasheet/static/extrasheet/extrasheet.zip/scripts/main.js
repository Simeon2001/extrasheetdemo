$(document).ready(function(){
    $('.sidenav').sidenav()
    $('.materialboxed').materialbox();
    $('.parallax').parallax();
    $('.tabs').tabs();
    $('.datepicker').datepicker({
    
    });
    $('.tooltipped').tooltip();
    $('.scrollspy').scrollSpy();
    
  });