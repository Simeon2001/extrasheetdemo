new Vue ({
  el: '#app',
  data: {
    message: ''
  }
});